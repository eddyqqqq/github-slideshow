/*!
 * Pavva – lista de ofertă (mai multe produse într-o singură cerere de ofertă)
 * Creat de Imagient (imagient.ro) pentru Pavva.
 *
 * Lista se ține în browserul vizitatorului (localStorage, fără cookie-uri), deci merge și cu paginile din cache.
 *
 * Ce recunoaște în pagină:
 *   [data-pvl-add]            butonul „Adaugă la ofertă” (widgetul Buton ofertă, cardurile din Grilă produse)
 *   .pv-oferta-add            orice element Elementor cu această clasă CSS: adaugă produsul paginii
 *   .pv-oferta-go             la fel, apoi deschide formularul
 *   [data-pvl-counter]        widgetul „Oferta ta” (iconiță + număr)
 *   [data-pvl-count], .pv-oferta-count   orice element: primește numărul de produse
 *   [data-pvl-list]           widgetul „Listă ofertă” (produsele alese, cu ștergere)
 *   <html class="pv-oferta-are">         când lista are produse (pentru CSS propriu)
 * În formular, câmpul „Produs solicitat” devine „adaugă în listă”, iar la trimitere primește toate produsele.
 *
 * window.PavvaLista: get(), add(item), remove(id), has(id), clear(), count()
 */
(function (w, d) {
	'use strict';
	/* o singură dată, chiar dacă scriptul ajunge de două ori în pagină (ex. optimizări de cache) */
	if (w.PavvaLista) return;

	var C = w.PavvaListaCfg || {};
	var KEY = 'pavva_oferta_v1';
	var MAX = 20;
	var memory = [];
	var dataCache = null;

	/* ---------- lista (localStorage, cu rezervă în memorie) ---------- */
	function read() {
		try {
			var v = JSON.parse(w.localStorage.getItem(KEY) || '[]');
			return Array.isArray(v) ? v.filter(function (it) { return it && it.name; }) : [];
		} catch (e) { return memory.slice(); }
	}
	function write(list) {
		memory = list.slice();
		try { w.localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) {}
		render();
	}
	function keyOf(it) { return it.id ? 'id:' + it.id : 'n:' + norm(it.name); }
	function find(list, it) {
		var k = keyOf(it);
		for (var i = 0; i < list.length; i++) if (keyOf(list[i]) === k) return i;
		return -1;
	}
	function clean(it) {
		return {
			id: parseInt(it.id, 10) || 0,
			name: String(it.name || '').trim(),
			cat: String(it.cat || '').trim(),
			url: String(it.url || ''),
			img: String(it.img || '')
		};
	}
	function add(it) {
		it = clean(it);
		if (!it.name) return false;
		var list = read();
		if (find(list, it) !== -1) return false;
		if (list.length >= MAX) { announce(txt('full', 'Lista are deja ' + MAX + ' produse.')); return false; }
		list.push(it);
		write(list);
		return true;
	}
	function remove(it) {
		var list = read();
		var i = find(list, typeof it === 'object' ? it : { id: it, name: String(it) });
		if (i === -1) return;
		list.splice(i, 1);
		write(list);
	}
	function has(it) { return find(read(), clean(it)) !== -1; }
	function clear() { write([]); }

	function norm(t) {
		return String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
	}
	function esc(t) {
		return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
	}
	function txt(k, def) { return (C.i18n && C.i18n[k]) || def; }
	function plural(n) { return n === 1 ? txt('one', '1 produs') : n + ' ' + txt('many', 'produse'); }
	function formUrl(el) {
		var u = el && el.getAttribute('data-pvl-form');
		return u || C.form || '/solicita-oferta/';
	}

	/* ---------- anunțuri pentru cititoarele de ecran + mesaj scurt pe ecran ---------- */
	var live = null, toastEl = null, toastT = 0;
	function announce(msg) {
		if (!live) {
			live = d.createElement('div');
			live.className = 'pvl-sr';
			live.setAttribute('aria-live', 'polite');
			live.setAttribute('role', 'status');
			d.body.appendChild(live);
		}
		live.textContent = '';
		setTimeout(function () { live.textContent = msg; }, 30);
	}
	/* bara de jos „Oferta ta: 3 produse · Vezi oferta”: rămâne cât lista are produse (nu și pe pagina formularului),
	   ca vizitatorul să ajungă ușor la formular după ce a ales; după o adăugare arată câteva secunde produsul adăugat */
	var BAR_OFF = 'pavva_oferta_bar_off';
	function barOff() { try { return w.sessionStorage.getItem(BAR_OFF) === '1'; } catch (e) { return false; } }
	function onFormPage() {
		if (forms.length) return true;
		try { return new URL(C.form || '/solicita-oferta/', w.location.href).pathname.replace(/\/+$/, '') === w.location.pathname.replace(/\/+$/, ''); } catch (e) { return false; }
	}
	function ensureBar() {
		if (toastEl) return toastEl;
		toastEl = d.createElement('div');
		toastEl.className = 'pvl-toast';
		toastEl.setAttribute('role', 'region');
		toastEl.setAttribute('aria-label', txt('title', 'Oferta ta'));
		toastEl.innerHTML = '<span class="pvl-toast-t"></span><a class="pvl-toast-a" href="#"></a>' +
			'<button type="button" class="pvl-toast-x" aria-label="' + esc(txt('hide', 'Ascunde bara')) + '">' + X + '</button>';
		d.body.appendChild(toastEl);
		toastEl.querySelector('.pvl-toast-x').addEventListener('click', function () {
			try { w.sessionStorage.setItem(BAR_OFF, '1'); } catch (e) {}
			toastEl.classList.remove('is-on');
		});
		return toastEl;
	}
	function bar(flashName, url) {
		var n = read().length;
		var show = C.bar !== false && n > 0 && !onFormPage() && !barOff() && !(dw && !dw.hidden);
		if (!show && !toastEl) return;
		var el = ensureBar();
		el.querySelector('.pvl-toast-a').setAttribute('href', url || C.form || '/solicita-oferta/');
		el.querySelector('.pvl-toast-a').textContent = txt('see', 'Vezi oferta');
		var t = el.querySelector('.pvl-toast-t');
		if (flashName) {
			t.innerHTML = esc(txt('added', 'Adăugat în ofertă')) + ': <strong>' + esc(flashName) + '</strong>';
			clearTimeout(toastT);
			toastT = setTimeout(function () { toastT = 0; bar(); }, 3500);
		} else if (!toastT) {
			t.innerHTML = esc(txt('title', 'Oferta ta')) + ': <strong>' + esc(plural(n)) + '</strong>';
		}
		el.classList.toggle('is-on', show || (!!flashName && C.bar === false));
		d.documentElement.classList.toggle('pv-oferta-bar', show);
	}
	function toast(name, url) {
		/* la adăugare, bara reapare chiar dacă a fost închisă */
		try { w.sessionStorage.removeItem(BAR_OFF); } catch (e) {}
		bar(name, url);
		if (C.bar === false) { clearTimeout(toastT); toastT = setTimeout(function () { toastT = 0; if (toastEl) toastEl.classList.remove('is-on'); }, 4200); }
	}

	/* ---------- produsul unui buton ---------- */
	function itemOf(el) {
		var raw = el.getAttribute('data-pvl');
		if (raw) { try { return clean(JSON.parse(raw)); } catch (e) {} }
		if (w.PavvaListaCurrent) return clean(w.PavvaListaCurrent);
		return null;
	}

	/* ---------- afișare: butoane, contoare, liste ---------- */
	function render() {
		navItems();
		var list = read();
		var n = list.length;
		d.documentElement.classList.toggle('pv-oferta-are', n > 0);

		each('[data-pvl-add], .pv-oferta-add, .pv-oferta-go', function (el) {
			var it = itemOf(el);
			var on = !!it && find(list, it) !== -1;
			el.classList.toggle('is-added', on);
			var btn = el.matches('button, a') ? el : el.querySelector('button, a');
			if (btn && btn.tagName === 'BUTTON') btn.setAttribute('aria-pressed', on ? 'true' : 'false');
		});

		each('[data-pvl-count], .pv-oferta-count', function (el) {
			if (el.closest('[data-pvl-preview]')) return;
			/* la elementele Elementor cu clasă: textul e în interior */
			var t = el.matches('[data-pvl-count]') ? el : (el.querySelector('.elementor-heading-title, .elementor-button-text, p, span') || el);
			t.textContent = String(n);
		});

		each('[data-pvl-counter]', function (el) {
			if (el.hasAttribute('data-pvl-preview')) return; /* în editor: exemplul rămâne vizibil, pentru stilizare */
			el.classList.toggle('is-empty', n === 0);
			var base = el.getAttribute('data-pvl-label') || txt('title', 'Oferta ta');
			el.setAttribute('aria-label', n ? base + ' – ' + plural(n) : base + ' – ' + txt('empty', 'niciun produs'));
			if (dcfg().on) el.setAttribute('aria-haspopup', 'dialog');
		});

		each('[data-pvl-list], [data-pvl-drawer-list]', renderList);
		drawerSync();
		forms.forEach(function (f) { f.sync(); });
		bar();
	}

	/* ---------- „Oferta ta” în meniul de navigare ----------
	   Appearance → Menus: un link (de ex. /solicita-oferta/) cu clasa CSS pv-oferta-nav
	   (+ pv-oferta-nav-icon = doar iconiță, + pv-oferta-nav-hide = ascuns cât lista e goală) */
	var ICON = '<svg class="pvl-nav-ico" viewBox="0 0 384 512" aria-hidden="true" focusable="false"><path fill="currentColor" d="M336 64h-80c0-35.3-28.7-64-64-64s-64 28.7-64 64H48C21.5 64 0 85.5 0 112v352c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48zM96 424c-13.3 0-24-10.7-24-24s10.7-24 24-24 24 10.7 24 24-10.7 24-24 24zm0-96c-13.3 0-24-10.7-24-24s10.7-24 24-24 24 10.7 24 24-10.7 24-24 24zm0-96c-13.3 0-24-10.7-24-24s10.7-24 24-24 24 10.7 24 24-10.7 24-24 24zm96-192c13.3 0 24 10.7 24 24s-10.7 24-24 24-24-10.7-24-24 10.7-24 24-24zm128 368c0 4.4-3.6 8-8 8H168c-4.4 0-8-3.6-8-8v-16c0-4.4 3.6-8 8-8h144c4.4 0 8 3.6 8 8v16zm0-96c0 4.4-3.6 8-8 8H168c-4.4 0-8-3.6-8-8v-16c0-4.4 3.6-8 8-8h144c4.4 0 8 3.6 8 8v16zm0-96c0 4.4-3.6 8-8 8H168c-4.4 0-8-3.6-8-8v-16c0-4.4 3.6-8 8-8h144c4.4 0 8 3.6 8 8v16z"/></svg>';
	function navItems() {
		each('.pv-oferta-nav', function (li) {
			var a = li.tagName === 'A' ? li : li.querySelector('a');
			if (!a || a.__pvl) return;
			a.__pvl = true;
			var label = (a.textContent || '').trim() || txt('title', 'Oferta ta');
			a.classList.add('pvl-nav');
			a.setAttribute('data-pvl-counter', '');
			a.setAttribute('data-pvl-label', label);
			if (li.classList.contains('pv-oferta-nav-hide')) a.setAttribute('data-pvl-hide-empty', '');
			var iconOnly = li.classList.contains('pv-oferta-nav-icon');
			if (iconOnly) {
				a.innerHTML = '<span class="pvl-c-ico">' + ICON + '<span class="pvl-badge" data-pvl-count>0</span></span><span class="pvl-sr">' + esc(label) + '</span>';
				a.classList.add('pvl-nav-icon');
			} else {
				var b = d.createElement('span');
				b.className = 'pvl-badge pvl-badge-inline';
				b.setAttribute('data-pvl-count', '');
				b.setAttribute('aria-hidden', 'true');
				a.appendChild(b);
			}
		});
	}
	function each(sel, fn) { Array.prototype.forEach.call(d.querySelectorAll(sel), fn); }

	var X = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>';
	function renderList(box) {
		if (box.hasAttribute('data-pvl-preview')) return; /* în editorul Elementor rămân produsele de exemplu */
		var list = read();
		var ul = box.querySelector('.pvl-items');
		if (!ul) return;
		var showImg = box.getAttribute('data-pvl-img') !== '0';
		var showCat = box.getAttribute('data-pvl-cat') !== '0';
		var html = '';
		list.forEach(function (it) {
			html += '<li class="pvl-item">' +
				(showImg ? '<span class="pvl-media">' + (it.img ? '<img src="' + esc(it.img) + '" alt="" loading="lazy" decoding="async">' : '') + '</span>' : '') +
				'<span class="pvl-info">' +
				(it.url ? '<a class="pvl-name" href="' + esc(it.url) + '">' + esc(it.name) + '</a>' : '<span class="pvl-name">' + esc(it.name) + '</span>') +
				(showCat && it.cat ? '<span class="pvl-cat">' + esc(it.cat) + '</span>' : '') +
				'</span>' +
				'<button type="button" class="pvl-remove" data-pvl-remove="' + esc(keyOf(it)) + '" aria-label="' + esc(txt('remove', 'Scoate din ofertă') + ': ' + it.name) + '">' + X + '</button>' +
				'</li>';
		});
		ul.innerHTML = html;
		box.classList.toggle('is-empty', list.length === 0);
		var cnt = box.querySelector('.pvl-title-count');
		if (cnt) cnt.textContent = list.length ? ' (' + list.length + ')' : '';
	}

	/* ---------- clicuri ---------- */
	d.addEventListener('click', function (e) {
		var rm = e.target.closest('[data-pvl-remove]');
		if (rm) {
			e.preventDefault();
			var k = rm.getAttribute('data-pvl-remove');
			var list = read();
			var victim = null;
			for (var i = 0; i < list.length; i++) if (keyOf(list[i]) === k) victim = list[i];
			if (victim) {
				/* focusul trece pe rândul următor (sau pe titlu), nu se pierde */
				var li = rm.closest('.pvl-item');
				var next = li && (li.nextElementSibling || li.previousElementSibling);
				remove(victim);
				announce(txt('removed', 'Scos din ofertă') + ': ' + victim.name);
				var box = rm.closest('[data-pvl-list], [data-pvl-drawer-list]') || d;
				var target = next && box.querySelector('[data-pvl-remove]');
				if (target) target.focus();
				else if (dw && dw.contains(box)) { var x = dw.querySelector('.pvl-dw-x'); if (x) x.focus(); }
			}
			return;
		}

		var cls = e.target.closest('[data-pvl-close]');
		if (cls) { e.preventDefault(); closeDrawer(); return; }

		/* iconița „Oferta ta”, linkul din meniu, „Vezi oferta” din bară sau orice element cu clasa pv-oferta-open → panoul */
		var op = e.target.closest('[data-pvl-counter], .pvl-toast-a, .pv-oferta-open');
		if (op && !op.closest('[data-pvl-preview]') && dcfg().on) { e.preventDefault(); openDrawer(op); return; }

		var cta = e.target.closest('.pvl-dw-cta');
		if (cta && onFormPage()) {
			/* suntem deja pe pagina formularului: închidem panoul și ducem vizitatorul la formular */
			e.preventDefault();
			closeDrawer(true);
			var fm = forms[0] && forms[0].form;
			if (fm) { fm.scrollIntoView({ behavior: 'smooth', block: 'start' }); var fld = fm.querySelector('input, select, textarea'); if (fld) setTimeout(function () { fld.focus({ preventScroll: true }); }, 500); }
			return;
		}

		var clr = e.target.closest('[data-pvl-clear]');
		if (clr) { e.preventDefault(); clear(); announce(txt('cleared', 'Lista a fost golită')); return; }

		var el = e.target.closest('[data-pvl-add], .pv-oferta-add, .pv-oferta-go');
		if (!el) return;
		var it = itemOf(el);
		if (!it || !it.name) return;
		e.preventDefault();
		var go = el.classList.contains('pv-oferta-go') || el.getAttribute('data-pvl-mode') === 'go';
		var again = el.getAttribute('data-pvl-again') || 'go';
		if (has(it)) {
			if (go || again === 'go') { w.location.href = formUrl(el); return; }
			remove(it);
			announce(txt('removed', 'Scos din ofertă') + ': ' + it.name);
			return;
		}
		add(it);
		if (go) { w.location.href = formUrl(el); return; }
		announce(txt('added', 'Adăugat în ofertă') + ': ' + it.name);
		if (dcfg().on && dcfg().auto) { openDrawer(el); return; }
		if (el.getAttribute('data-pvl-toast') !== '0') toast(it.name, formUrl(el));
	});

	/* ---------- panoul lateral „Oferta ta” (ca un coș de cumpărături) ----------
	   Setările vin din widgetul „Oferta ta” (atributele data-pvl-* de pe iconiță); fără widget: valorile implicite. */
	var dw = null, dwLast = null, dwT = 0;
	function dcfg() {
		var el = d.querySelector('[data-pvl-counter][data-pvl-drawer]');
		var g = function (k, def) { var v = el && el.getAttribute('data-pvl-' + k); return v === null || v === undefined || v === '' ? def : v; };
		return {
			on: C.drawer !== false && g('drawer', '1') !== '0',
			side: g('side', 'right') === 'left' ? 'left' : 'right',
			auto: g('auto', '0') === '1',
			title: g('t-title', txt('title', 'Oferta ta')),
			cta: g('t-cta', txt('cta', 'Solicită ofertă')),
			more: g('t-more', txt('more', 'Continuă să alegi')),
			empty: g('t-empty', txt('dwEmpty', 'Nu ai adăugat încă niciun produs. Apasă „Adaugă la ofertă” pe produsele care te interesează.')),
			browse: g('t-browse', txt('browse', 'Vezi produsele')),
			browseUrl: g('browse-url', ''),
			form: g('form', C.form || '/solicita-oferta/')
		};
	}
	function buildDrawer() {
		if (dw) return dw;
		var c = dcfg();
		dw = d.createElement('div');
		dw.className = 'pvl-drawer pvl-drawer-' + c.side;
		dw.hidden = true;
		dw.innerHTML =
			'<div class="pvl-dw-overlay" data-pvl-close></div>' +
			'<div class="pvl-dw-panel" role="dialog" aria-modal="true" aria-labelledby="pvl-dw-title" tabindex="-1" data-lenis-prevent>' +
				'<div class="pvl-dw-head"><h2 class="pvl-dw-title" id="pvl-dw-title">' + esc(c.title) + '<span class="pvl-dw-count"></span></h2>' +
				'<button type="button" class="pvl-dw-x" data-pvl-close aria-label="' + esc(txt('close', 'Închide')) + '">' + X + '</button></div>' +
				'<div class="pvl-dw-body">' +
					'<div class="pvl-list pvl-dw-list" data-pvl-drawer-list data-pvl-img="1" data-pvl-cat="1"><ul class="pvl-items"></ul></div>' +
					'<div class="pvl-dw-empty"><p>' + esc(c.empty) + '</p>' +
						(c.browseUrl ? '<a class="pvl-dw-browse" href="' + esc(c.browseUrl) + '">' + esc(c.browse) + '</a>' : '<button type="button" class="pvl-dw-browse" data-pvl-close>' + esc(c.browse) + '</button>') +
					'</div>' +
				'</div>' +
				'<div class="pvl-dw-foot">' +
					'<a class="pvl-dw-cta" href="' + esc(c.form) + '">' + esc(c.cta) + '</a>' +
					'<button type="button" class="pvl-dw-more" data-pvl-close>' + esc(c.more) + '</button>' +
				'</div>' +
			'</div>';
		d.body.appendChild(dw);
		renderList(dw.querySelector('[data-pvl-drawer-list]'));
		drawerSync();
		return dw;
	}
	function drawerSync() {
		if (!dw) return;
		var n = read().length;
		dw.classList.toggle('is-empty', n === 0);
		dw.querySelector('.pvl-dw-count').textContent = n ? ' (' + n + ')' : '';
	}
	function focusables() {
		return Array.prototype.filter.call(dw.querySelectorAll('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'), function (el) { return el.offsetWidth || el.offsetHeight; });
	}
	function openDrawer(from) {
		buildDrawer();
		dwLast = from || d.activeElement;
		clearTimeout(dwT);
		dw.hidden = false;
		d.documentElement.classList.add('pvl-dw-open');
		/* bara de jos nu mai are rost cât panoul e deschis */
		if (toastEl) toastEl.classList.remove('is-on');
		requestAnimationFrame(function () { requestAnimationFrame(function () { dw.classList.add('is-open'); }); });
		setTimeout(function () { var x = dw.querySelector('.pvl-dw-x'); if (x) x.focus({ preventScroll: true }); }, 60);
	}
	function closeDrawer(noFocus) {
		if (!dw || dw.hidden) return;
		dw.classList.remove('is-open');
		d.documentElement.classList.remove('pvl-dw-open');
		var back = !noFocus && dwLast && dwLast.focus && d.contains(dwLast) ? dwLast : null;
		/* butonul din bara de jos reapare abia după închidere: focusul revine pe el atunci */
		var later = back && toastEl && toastEl.contains(back);
		dwT = setTimeout(function () { dw.hidden = true; bar(); if (later) back.focus({ preventScroll: true }); }, 320);
		if (back && !later) back.focus({ preventScroll: true });
	}
	d.addEventListener('keydown', function (e) {
		if (!dw || dw.hidden) return;
		if (e.key === 'Escape') { e.preventDefault(); closeDrawer(); return; }
		if (e.key !== 'Tab') return;
		/* focusul rămâne în panou cât e deschis */
		var f = focusables();
		if (!f.length) return;
		var first = f[0], last = f[f.length - 1];
		if (e.shiftKey && (d.activeElement === first || !dw.contains(d.activeElement))) { e.preventDefault(); last.focus(); }
		else if (!e.shiftKey && (d.activeElement === last || !dw.contains(d.activeElement))) { e.preventDefault(); first.focus(); }
	});

	/* tastatura pe elementele Elementor cu clasă (care nu sunt butoane) */
	d.addEventListener('keydown', function (e) {
		if (e.key !== 'Enter' && e.key !== ' ') return;
		var el = e.target.closest('.pv-oferta-add, .pv-oferta-go');
		if (el && !e.target.closest('button, a')) { e.preventDefault(); el.click(); }
	});

	/* altă filă a browserului a schimbat lista */
	w.addEventListener('storage', function (e) { if (e.key === KEY) render(); });

	/* „Înapoi” în browser: pagina revine din memorie exact cum a fost lăsată (panou deschis, butoane vechi).
	   Panoul se închide înainte de plecare și totul se recitește la întoarcere. */
	function shutDrawerNow() {
		if (!dw) return;
		clearTimeout(dwT);
		dw.classList.remove('is-open');
		dw.hidden = true;
		d.documentElement.classList.remove('pvl-dw-open');
	}
	w.addEventListener('pagehide', shutDrawerNow);
	w.addEventListener('pageshow', function (e) { if (e.persisted) { shutDrawerNow(); render(); } });
	d.addEventListener('visibilitychange', function () { if (d.visibilityState === 'visible') render(); });

	/* ---------- formularul de ofertă ---------- */
	var forms = [];

	function bindForm(form, cat, prod, D) {
		if (!form || form.__pvl || !prod || prod.tagName !== 'SELECT') return;
		form.__pvl = true;
		var prods = (D && D.prods) || [];
		var byName = {};
		prods.forEach(function (p) { byName[norm(p.name)] = p; });

		/* produsele din listă se actualizează după catalog (nume schimbat, produs șters) */
		if (prods.length && prods[0].id) {
			var byId = {};
			prods.forEach(function (p) { byId[p.id] = p; });
			var list = read(), changed = false;
			list = list.filter(function (it) {
				var p = it.id ? byId[it.id] : byName[norm(it.name)];
				if (!p) { changed = true; return false; }
				['name', 'cat', 'url', 'img'].forEach(function (k) { if (p[k] !== undefined && it[k] !== p[k]) { it[k] = p[k]; changed = true; } });
				if (!it.id && p.id) { it.id = p.id; changed = true; }
				return true;
			});
			if (changed) { memory = list; try { w.localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) {} }
		}

		var ph = null;
		var summary = d.createElement('option');
		summary.setAttribute('data-pvl-summary', '');
		var catsOpt = null, catPrev = '';

		function lines(list) {
			return list.map(function (it, i) { return (i + 1) + '. ' + it.name + (it.cat ? ' (' + it.cat + ')' : ''); }).join('\n');
		}

		function sync() {
			var list = read();
			/* textul de început: „+ Adaugă alt produs” cât timp lista are produse */
			var first = prod.options[0];
			if (ph === null) ph = prod.__pvoPh || (first && !first.value ? first.textContent : '');
			if (first && !first.value && !first.hasAttribute('data-pvl-summary')) first.textContent = list.length ? txt('pick', '+ Adaugă alt produs') : ph;
			/* cu produse în listă, categoria devine doar un filtru pentru „+ Adaugă alt produs” (nu mai e obligatorie);
			   goală = toate produsele. La trimitere primește oricum categoriile produselor din listă. */
			if (cat && cat.tagName === 'SELECT') {
				if (cat.__pvlReq === undefined) cat.__pvlReq = cat.required;
				cat.required = list.length ? false : cat.__pvlReq;
				if (list.length) cat.removeAttribute('aria-required'); else if (cat.__pvlReq) cat.setAttribute('aria-required', 'true');
			}
			if (!list.length) {
				if (summary.parentNode) summary.parentNode.removeChild(summary);
				if (prod.value && prod.value === summary.value) prod.value = '';
				return;
			}
			summary.value = lines(list);
			summary.textContent = list.length === 1 ? list[0].name : list[0].name + ' + ' + plural(list.length - 1);
			if (summary.parentNode !== prod) prod.insertBefore(summary, prod.options[1] || null);
			summary.selected = true;
			prod.value = summary.value;
		}

		/* alegi un produs din listă → intră în ofertă, iar câmpul arată din nou rezumatul */
		prod.addEventListener('change', function () {
			var v = prod.value;
			if (!v || v === summary.value) return;
			var p = byName[norm(v)] || { name: v, cat: cat && cat.value ? cat.value : '' };
			add(p);
			announce(txt('added', 'Adăugat în ofertă') + ': ' + p.name);
		});
		/* lista de produse se reface când schimbi categoria: punem rezumatul la loc */
		if (cat) cat.addEventListener('change', function () { setTimeout(sync, 0); });

		/* la trimitere: ambele câmpuri primesc toate produsele / categoriile (înaintea scriptului formularului) */
		function beforeSubmit() {
			var list = read();
			if (!list.length) return;
			sync();
			if (cat && cat.tagName === 'SELECT') {
				var cats = [];
				list.forEach(function (it) { if (it.cat && cats.indexOf(it.cat) === -1) cats.push(it.cat); });
				/* și cu o singură categorie: câmpul (acum opțional, folosit ca filtru) poate fi gol sau pe altă categorie */
				if (cats.length) {
					if (!catsOpt) { catsOpt = d.createElement('option'); catsOpt.setAttribute('data-pvl-cats', ''); }
					if (catsOpt.parentNode !== cat) { catPrev = cat.value; cat.appendChild(catsOpt); }
					catsOpt.value = cats.join(', ');
					catsOpt.textContent = cats.join(', ');
					cat.value = catsOpt.value;
				}
			}
		}
		/* după trimitere, la prima atingere a categoriei, revine valoarea de filtrare */
		function restoreCat() {
			if (catsOpt && catsOpt.parentNode) { catsOpt.parentNode.removeChild(catsOpt); cat.value = catPrev; }
		}
		if (cat) ['pointerdown', 'focus', 'keydown'].forEach(function (t) { cat.addEventListener(t, restoreCat); });

		/* trimis cu succes → lista se golește */
		var okSel = '[data-element_type="e-form-success-message"], .elementor-message-success, .wpcf7-mail-sent-ok, .wpforms-confirmation-container';
		function visible(el) { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length) && getComputedStyle(el).visibility !== 'hidden'); }
		/* formularul Elementor V4 primește clasa form-state-success (la ea pornește și redirecționarea spre „Mulțumim”) */
		function success() {
			return form.classList.contains('form-state-success') ||
				Array.prototype.some.call(form.querySelectorAll(okSel), visible) ||
				!!(form.parentNode && form.parentNode.querySelector('.elementor-message-success'));
		}
		var shownAtStart = success();
		var pending = false;
		function checkOk() {
			if (!pending) return;
			if (success() && !shownAtStart) { pending = false; restoreCat(); clear(); }
		}
		if (w.MutationObserver) new MutationObserver(checkOk).observe(form, { attributes: true, childList: true, subtree: true });
		if (w.jQuery) w.jQuery(form).on('submit_success', function () { pending = true; checkOk(); restoreCat(); clear(); });

		var api = { form: form, sync: sync, before: function () { beforeSubmit(); pending = true; } };
		forms.push(api);

		/* lista se pune în formular, deasupra câmpurilor de produs:
		   widgetul „Listă ofertă” (cu „Așază în formular”), altfel o listă automată */
		var anchor = cat && form.contains(cat) ? cat : prod;
		var node = anchor;
		while (node.parentElement && node.parentElement !== form) node = node.parentElement;
		var widget = d.querySelector('[data-pvl-list][data-pvl-into-form]');
		var box = null;
		if (widget && !form.contains(widget)) {
			/* se mută tot widgetul Elementor, ca stilurile lui să rămână valabile */
			box = widget.closest('.elementor-element') || widget;
			form.insertBefore(box, node);
			box = widget;
		} else if (!d.querySelector('[data-pvl-list]') && C.autoList !== false) {
			box = d.createElement('div');
			box.className = 'pvl-list pvl-list-auto is-empty';
			box.setAttribute('data-pvl-list', '');
			box.innerHTML = '<p class="pvl-title">' + esc(txt('listTitle', 'Produsele tale')) + '<span class="pvl-title-count"></span></p>' +
				'<ul class="pvl-items"></ul>' +
				'<p class="pvl-empty">' + esc(txt('listEmpty', 'Alege produsele dorite din lista de mai jos. Poți adăuga mai multe.')) + '</p>';
			form.insertBefore(box, node);
		}
		if (box) {
			/* titlul și textul încep la fel ca textul din câmpuri (padding-ul + chenarul câmpului) */
			box.classList.add('pvl-in-form');
			var cs = getComputedStyle(anchor);
			var pad = (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.borderLeftWidth) || 0);
			if (box.getAttribute('data-pvl-align') !== '0') box.style.setProperty('--pvl-field-pad', pad + 'px');
		}
		render();
	}

	/* capturăm trimiterea înaintea scriptului formularului (Elementor citește câmpurile în același moment) */
	d.addEventListener('submit', function (e) {
		forms.forEach(function (f) { if (f.form === e.target) f.before(); });
	}, true);

	/* oferta.js anunță formularele cu categorie / produs (după ce le-a completat) */
	d.addEventListener('pavva:oferta-form', function (e) {
		var x = e.detail || {};
		bindForm(e.target, x.categorie, x.produs, x.data);
	});

	function start() {
		each('form', function (form) {
			var x = form.__pvoProducts;
			if (x) bindForm(form, x.categorie, x.produs, x.data);
		});
		render();
	}
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();

	w.PavvaLista = { get: read, add: add, remove: remove, has: has, clear: clear, count: function () { return read().length; }, open: function () { openDrawer(); }, close: function () { closeDrawer(); } };
})(window, document);
